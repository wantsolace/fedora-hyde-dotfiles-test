# HyDE → Fedora 44 Port: Known Issues & Bug Analysis
# =====================================================
# Generated: 2026-05-31  |  HyDE version: master (v26.03.30+)
# Fedora target: Fedora 44 (DNF5, kernel 6.12+)

---

## COPR Repositories Used

| COPR                   | What it provides                                              | Maintained? |
|------------------------|---------------------------------------------------------------|-------------|
| solopasha/hyprland     | hyprland, hyprlock, hypridle, swww, grimblast, wlogout, uwsm | ✅ Actively  |
| heus-sueh/packages     | matugen (wallbash color engine)                               | ✅ Actively  |
| RPM Fusion (free/nonfree) | ffmpegthumbs, NVIDIA drivers, misc multimedia              | ✅ Actively  |

---

## Package Mapping (Arch → Fedora)

| Arch/AUR package              | Fedora equivalent            | Source         | Notes                                      |
|-------------------------------|------------------------------|----------------|--------------------------------------------|
| hyprland                      | hyprland                     | solopasha COPR | Same version tracking upstream             |
| hyprlock                      | hyprlock                     | solopasha COPR | replaces swaylock-effects-git              |
| hypridle                      | hypridle                     | solopasha COPR | identical                                  |
| hyprpaper                     | hyprpaper                    | solopasha COPR | identical                                  |
| hyprpicker-git                | hyprpicker                   | solopasha COPR | stable release, no -git suffix needed      |
| hyprsunset                    | hyprsunset                   | solopasha COPR | identical                                  |
| hyprpolkitagent               | hyprpolkitagent              | solopasha COPR | identical                                  |
| xdg-desktop-portal-hyprland   | xdg-desktop-portal-hyprland  | solopasha COPR | identical                                  |
| uwsm                          | uwsm                         | solopasha COPR | HyDE v26+ session manager                 |
| swww                          | swww                         | solopasha COPR | identical                                  |
| waybar                        | waybar                       | Fedora repos   | identical, slightly older                  |
| rofi-lbonn-wayland-git        | rofi-wayland                 | Fedora repos   | Drop-in replacement, fully compatible      |
| dunst                         | dunst                        | Fedora repos   | identical                                  |
| grimblast-git                 | grimblast                    | solopasha COPR | solopasha ships stable grimblast           |
| grim                          | grim                         | Fedora repos   | identical                                  |
| slurp                         | slurp                        | Fedora repos   | identical                                  |
| swappy                        | swappy                       | Fedora repos   | identical                                  |
| cliphist                      | cliphist                     | solopasha COPR | identical                                  |
| wl-clipboard                  | wl-clipboard                 | Fedora repos   | identical                                  |
| wl-clip-persist               | wl-clip-persist              | solopasha COPR | identical                                  |
| wlogout                       | wlogout                      | solopasha COPR | identical                                  |
| matugen-bin                   | matugen                      | heus-sueh COPR | identical binary, different package name   |
| nwg-look                      | nwg-look                     | solopasha COPR | identical                                  |
| qt5ct                         | qt5ct                        | Fedora repos   | identical                                  |
| qt6ct                         | qt6ct                        | Fedora repos   | identical                                  |
| kvantum                       | kvantum                      | Fedora repos   | identical                                  |
| kvantum-qt5                   | kvantum-qt5                  | Fedora repos   | identical                                  |
| pipewire, wireplumber         | same                         | Fedora repos   | Fedora ships these by default              |
| pamixer                       | pamixer                      | Fedora repos   | identical                                  |
| playerctl                     | playerctl                    | Fedora repos   | identical                                  |
| kitty                         | kitty                        | Fedora repos   | identical                                  |
| dolphin                       | dolphin                      | Fedora repos   | identical                                  |
| ffmpegthumbs                  | ffmpegthumbs                 | RPM Fusion     | identical                                  |
| qt5-imageformats              | qt5-qtimageformats           | Fedora repos   | renamed package                            |
| kde-cli-tools                 | kde-cli-tools                | Fedora repos   | identical                                  |
| blueman                       | blueman                      | Fedora repos   | identical                                  |
| network-manager-applet        | network-manager-applet       | Fedora repos   | identical                                  |
| udiskie                       | udiskie                      | Fedora repos   | identical                                  |
| sddm                          | sddm                         | Fedora repos   | identical                                  |
| polkit-kde-agent              | hyprpolkitagent              | solopasha COPR | HyDE now recommends hyprpolkitagent        |
| python-pyamdgpuinfo           | python3-pyamdgpuinfo         | solopasha COPR | renamed for Python3                        |
| imagemagick                   | ImageMagick                  | Fedora repos   | case difference in package name            |
| parallel                      | parallel                     | Fedora repos   | identical                                  |
| jq                            | jq                           | Fedora repos   | identical                                  |
| pacman-contrib                | dnf-plugins-core             | Fedora repos   | checkupdates → dnf check-update            |
| ttf-jetbrains-mono-nerd       | (manual install)             | GitHub release | No RPM, downloaded by install.sh           |
| noto-fonts-emoji              | google-noto-emoji-fonts      | Fedora repos   | renamed                                    |
| brightnessctl                 | brightnessctl                | Fedora repos   | identical                                  |
| btop                          | btop                         | Fedora repos   | identical                                  |
| fastfetch                     | fastfetch                    | Fedora repos   | identical                                  |
| eza                           | eza                          | Fedora repos   | identical (was exa, fully renamed)         |
| bat                           | bat                          | Fedora repos   | identical                                  |
| fd                            | fd-find                      | Fedora repos   | installs fd binary (not fdfind like Ubuntu)|
| ripgrep                       | ripgrep                      | Fedora repos   | identical                                  |
| fzf                           | fzf                          | Fedora repos   | identical                                  |
| yazi                          | yazi                         | Fedora repos   | identical                                  |
| starship                      | starship                     | Fedora repos   | identical                                  |
| socat                         | socat                        | Fedora repos   | identical                                  |
| gnome-keyring                 | gnome-keyring                | Fedora repos   | identical                                  |
| power-profiles-daemon         | power-profiles-daemon        | Fedora repos   | identical                                  |

---

## Known Bugs & Compatibility Issues

### 🔴 Critical

**1. HyDE install.sh uses `pacman` / `yay` — CANNOT run on Fedora**
- The upstream `~/HyDE/Scripts/install.sh` calls `pacman` and `yay` directly.
- **Fix:** Our `install.sh` replaces the entire Arch install logic with DNF + COPR.
- The HyDE _configs_ (Configs/ directory) are distro-agnostic and deploy fine.

**2. polkit-kde-authentication-agent-1 binary path differs**
- Arch: `/usr/lib/polkit-kde-authentication-agent-1`
- Fedora: `/usr/libexec/polkit-kde-authentication-agent-1`
- **Fix:** install.sh patches this path. HyDE now uses `hyprpolkitagent` instead which
  sidesteps this entirely (same path on both distros).

**3. Hyprland not in Fedora official repos (F44)**
- Fedora 44 does not ship Hyprland in official repositories.
- **Fix:** solopasha/hyprland COPR provides up-to-date builds and is actively maintained.
  This is the same COPR that HyprPanel, JaKooLit, and other major projects recommend.

---

### 🟡 Medium

**4. swww COPR priority conflict**
- Both solopasha/hyprland and heus-sueh/packages provide swww.
- If priorities are not set, dnf may pick the wrong version.
- **Fix:** install.sh sets solopasha to priority=90 (lower number = higher priority).

**5. rofi: scaling/font issues on first launch**
- If rofi (non-wayland) was previously installed, it conflicts with rofi-wayland.
- Symptoms: wrong scale, garbled UI, crash.
- **Fix:** `sudo dnf remove rofi && sudo dnf install rofi-wayland`.
  The install script installs only rofi-wayland; ensure old rofi is gone first.

**6. XDG portal race condition on Hyprland startup**
- xdg-desktop-portal-hyprland sometimes starts before Hyprland is fully ready.
- Symptom: screen sharing broken, file pickers don't open.
- **Fix:** install.sh creates `~/.local/bin/fix-xdg-portal.sh` and adds it to
  Hyprland's exec-once. Also, HyDE's own startup should handle this via uwsm.

**7. NVIDIA: nouveau blacklist + DRM modeset required**
- Hyprland requires `nvidia-drm.modeset=1` on kernel cmdline.
- Fedora does not set this by default.
- **Fix:** install.sh adds kernel args via `grubby` and blacklists nouveau.
  Reboot required after installation.

**8. NVIDIA: older cards (GTX 970 and before) need `akmod-nvidia-470xx`**
- install.sh installs `akmod-nvidia` (latest driver).
- Maxwell/Pascal era (GTX 700-1000): use `akmod-nvidia` — should work.
- Kepler/Fermi era (GTX 600 and older): may need `akmod-nvidia-470xx` from RPM Fusion.
- **Fix:** Edit install.sh's `setup_nvidia()` function if you have an old GPU.

**9. SDDM Wayland mode quirks**
- SDDM on Fedora may default to X11 backend.
- HyDE's session files work best with the Wayland SDDM backend.
- **Fix:** install.sh writes `/etc/sddm.conf.d/hyprland.conf` with
  `DisplayServer=wayland`. If SDDM fails to start, try removing that file.

**10. GDM is Fedora Workstation's default display manager**
- install.sh disables GDM and enables SDDM.
- If you prefer to keep GDM: set SDDM=skip in install.sh; you can still launch
  Hyprland from GDM by selecting the session. Note: GDM may not show wayland sessions
  from COPR without additional setup.

---

### 🟢 Minor / Informational

**11. waybar workspace module**
- Older Fedora (≤39) had waybar < 0.10.3 which broke Hyprland workspace display.
- Fedora 44 ships a recent waybar — no issue.

**12. `checkupdates` script (pacman-contrib) not available**
- HyDE's waybar update module uses `checkupdates` (pacman-contrib).
- The Fedora port replaces this with a DNF-based count:
  `dnf check-update -q 2>/dev/null | grep -c "^[^ ]"`.
- The waybar module config patch handles this automatically.

**13. ImageMagick package name**
- Fedora: `ImageMagick` (capital I and M), not `imagemagick`.
- DNF is case-insensitive for install, but scripts calling `imagemagick` in shebangs
  or paths will fail. The binary is `magick` on both distros (v7+).

**14. `fd` vs `fdfind`**
- Fedora's `fd-find` package installs the binary as `fd` (not `fdfind` like Ubuntu/Debian).
- No shim needed; HyDE scripts using `fd` work as-is.

**15. Nerd Fonts not in Fedora repos**
- JetBrainsMono Nerd Font is not packaged for Fedora.
- install.sh downloads it directly from the Nerd Fonts GitHub releases page.
- Requires internet access during installation.

**16. python3-pyamdgpuinfo availability**
- May not always be in solopasha COPR. If missing:
  `pip3 install --user pyamdgpuinfo`
  The waybar AMD GPU module will work without it if GPU monitoring is disabled.

**17. wl-clip-persist may be missing**
- If solopasha doesn't have it for F44:
  `sudo dnf install clipse` as an alternative, or build from source.
  HyDE falls back gracefully if clipboard persistence daemon is absent.

**18. uwsm session file**
- install.sh creates `/usr/share/wayland-sessions/hyprland-uwsm.desktop` if missing.
- HyDE v26+ requires uwsm for proper session management and systemd service isolation.

---

## Things That Work Identically on Fedora

- All HyDE config files in `Configs/` (hyprland.conf, waybar, rofi, dunst, kitty, etc.)
- swww wallpaper daemon
- grimblast screenshot workflow
- hyprlock screen locking
- wallbash / matugen color generation
- dunst notifications
- cliphist clipboard manager
- wlogout logout menu
- All HyDE theme switching scripts
- All keybindings
- SDDM theme installation

---

## Update Procedure (Fedora)

```bash
# Update HyDE configs
cd ~/HyDE
git fetch --depth 1 origin master
git reset --hard origin/master
./install.sh --restore   # re-deploy configs with backup

# Update packages
sudo dnf upgrade
```

---

## Uninstall

```bash
# Remove packages (example — adjust to your installed list)
sudo dnf remove hyprland hyprlock hypridle swww waybar rofi-wayland dunst \
    grimblast wlogout cliphist hyprpicker hyprsunset uwsm

# Disable COPRs
sudo dnf copr disable solopasha/hyprland
sudo dnf copr disable heus-sueh/packages

# Restore your old configs from backup
ls ~/.config/cfg_backups/
cp -a ~/.config/cfg_backups/<timestamp>/* ~/.config/
```
