# HyDE on Fedora 44 — Manual Port

A clean, 1:1 port of [HyDE-Project/HyDE](https://github.com/HyDE-Project/HyDE) (master/latest) to **Fedora 44**.
All HyDE dotfiles are pulled directly from upstream — this repo just provides the install infrastructure.

---

## What's Included

```
.
├── install.sh              ← Main installer (run this)
├── patches/
│   └── systemupdate.sh     ← Fedora DNF replacement for waybar update counter
├── BUGS_AND_NOTES.md       ← Full bug analysis & Arch→Fedora package map
└── README.md               ← This file
```

---

## Requirements

- **Fedora 44** (also works on 42/43)
- A working internet connection
- At least 10 GB of free disk space
- A **non-root** user account with sudo privileges

---

## Quick Start

```bash
git clone https://github.com/your-fork/hyde-fedora ~/hyde-fedora
cd ~/hyde-fedora
chmod +x install.sh
./install.sh
```

**Back up your system first.** The script backs up existing `~/.config/` entries,
but a full system snapshot (Timeshift/Snapper) is strongly recommended.

---

## Installation Modes

```bash
./install.sh              # Full install: packages + dotfiles
./install.sh --no-dots    # Packages only (skip dotfile deployment)
./install.sh --restore    # Re-apply dotfiles only (packages already installed)
./install.sh --nvidia     # Force NVIDIA driver setup even without detection
```

---

## What the Installer Does

1. **Enables COPR repos**: `solopasha/hyprland` + `heus-sueh/packages`
2. **Enables RPM Fusion** (free + nonfree) for multimedia and NVIDIA
3. **Updates the system** (`dnf upgrade`)
4. **Installs all packages** grouped by function (see table below)
5. **Handles NVIDIA** drivers + DRM kernel args + nouveau blacklist
6. **Downloads JetBrainsMono Nerd Font** (not in Fedora repos)
7. **Backs up** existing `~/.config/` entries
8. **Clones HyDE master** from GitHub
9. **Deploys HyDE dotfiles** to `~/.config/` and `~/.local/`
10. **Applies Fedora patches**: polkit path, XDG portal, session file
11. **Configures SDDM** and disables GDM if present
12. **Enables services**: NetworkManager, bluetooth, sddm, power-profiles-daemon
13. **Sets up zsh + oh-my-zsh**

---

## Key Package Decisions

| Arch original           | Fedora replacement        | Reason                                      |
|-------------------------|---------------------------|---------------------------------------------|
| rofi-lbonn-wayland-git  | rofi-wayland              | Native Fedora pkg, 100% API-compatible      |
| swaylock-effects-git    | hyprlock                  | HyDE now officially uses hyprlock           |
| grimblast-git           | grimblast (solopasha)     | Same tool, stable release                   |
| polkit-kde-agent        | hyprpolkitagent           | HyDE's recommended polkit agent since v26   |
| matugen-bin             | matugen (heus-sueh)       | Same binary, different packaging            |
| pacman-contrib          | dnf-utils equivalent      | checkupdates → custom DNF script (patched)  |

---

## After Installation

1. **Reboot** your system
2. At the SDDM login screen, select **Hyprland (uwsm)** from the session menu
3. Log in

### Basic Keybindings (HyDE defaults)

| Key                   | Action                        |
|-----------------------|-------------------------------|
| `Super + Enter`       | Open terminal (kitty)         |
| `Super + Space`       | App launcher (rofi)           |
| `Super + Q`           | Close window                  |
| `Super + T`           | Cycle themes                  |
| `Super + Shift+W`     | Change wallpaper (swww)       |
| `Super + L`           | Lock screen (hyprlock)        |
| `Super + Shift+K`     | Keybind cheatsheet (rofi)     |
| `Print`               | Screenshot (grimblast)        |
| `Super + V`           | Clipboard history (cliphist)  |
| `Super + Delete`      | Logout menu (wlogout)         |

---

## Known Issues

See [BUGS_AND_NOTES.md](BUGS_AND_NOTES.md) for the full analysis.

**TL;DR for common problems:**

- **Rofi looks wrong**: `sudo dnf remove rofi; sudo dnf install rofi-wayland`
- **Screen sharing broken**: Run `~/.local/bin/fix-xdg-portal.sh`
- **NVIDIA black screen at SDDM**: Press `Ctrl+Alt+F2`, login via TTY, check
  `/etc/modprobe.d/blacklist-nouveau.conf` and that DRM args are in `/proc/cmdline`
- **Waybar workspace numbers missing**: Ensure `hyprland` version ≥ 0.40 from solopasha COPR

---

## Updating HyDE

```bash
cd ~/HyDE
git fetch --depth 1 origin master
git reset --hard origin/master

# Re-apply configs (existing configs backed up automatically):
cd ~/hyde-fedora
./install.sh --restore
```

---

## Credits

- [HyDE-Project/HyDE](https://github.com/HyDE-Project/HyDE) — the actual dotfiles
- [solopasha](https://copr.fedorainfracloud.org/coprs/solopasha/hyprland/) — Fedora Hyprland COPR
- [heus-sueh](https://copr.fedorainfracloud.org/coprs/heus-sueh/packages/) — matugen COPR
- [JaKooLit/Fedora-Hyprland](https://github.com/JaKooLit/Fedora-Hyprland) — reference for Fedora scripting patterns
